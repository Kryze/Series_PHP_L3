<?php $__env->startSection('head'); ?>
    @parent
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?>
    @parent
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bodyaccueil'); ?>
    @parent
<?php $__env->stopSection(); ?>
<?php $__env->startSection('carousel'); ?>
    @parent
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    @parent
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inscription'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.test', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>