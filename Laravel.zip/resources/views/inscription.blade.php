@extends('layouts.test')
@section('head')
    @parent
@endsection
@section('sidebar')
    @parent
@endsection
@section('bodyaccueil')
@endsection
@section('footer')
    @parent
@endsection
@section('inscription')
	@parent
@endsection

